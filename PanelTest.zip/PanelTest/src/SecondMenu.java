import javax.swing.*;
import java.awt.*;

/**
 * Created by Nick on 26.06.2017.
 */
public class SecondMenu extends JFrame {
    private JLabel label1 = new JLabel("Peak #1: ");
    private JLabel label2 = new JLabel("Peak #2:  ");
    private JLabel label3 = new JLabel("Weight:  ");
    private JTextField text1 = new JTextField(20);
    private JTextField text2 = new JTextField(20);
    private JTextField text3 = new JTextField(20);
    private JButton buttonExit = new JButton("Exit");
    private JButton buttonStart = new JButton("Start");

    public SecondMenu() {
        super("Menu 2");

        // create a new panel with GridBagLayout manager
        JPanel newPanel = new JPanel(new GridBagLayout());

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(10, 10, 10, 10);


        constraints.gridx = 0;
        constraints.gridy = 0;
        newPanel.add(label1, constraints);

        constraints.gridx = 1;
        newPanel.add(text1, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        newPanel.add(label2, constraints);

        constraints.gridx = 1;
        newPanel.add(text2, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        newPanel.add(label3, constraints);

        constraints.gridx = 1;
        newPanel.add(text1, constraints);


        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        newPanel.add(buttonStart, constraints);


        // set border for the panel
        newPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Menu #2"));

        // add the panel to this frame
        add(newPanel);

        pack();
        setLocationRelativeTo(null);
    }
}